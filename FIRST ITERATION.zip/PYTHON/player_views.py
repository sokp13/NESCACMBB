import math
from flask import Blueprint, render_template
from loader import load_data_from_csv

player_views = Blueprint('player', __name__)

# Per-game averages #
def ppg(pts, gp):
    if gp == 0:
        return 0
    else:
        return float(pts/gp)
def rpg(reb, gp):
    if gp == 0:
        return 0
    else:
        return float(reb/gp)
def apg(ast, gp):
    if gp == 0:
        return 0
    else:
        return float(ast/gp)
def bpg(blk, gp):
    if gp == 0:
        return 0
    else:
        return float(blk/gp)
def spg(stl, gp):
    if gp == 0:
        return 0
    else:
        return float(stl/gp)

# Advanced statistics #
def ppp(pts, poss):
    try:
        if poss == 0:
            return 0
        else:
            return float(pts/poss)
    except ValueError:
        return 0
def atr(ast, tov):
    if tov == 0:
        return ast
    else:
        return float(ast/tov)
def fg_pct(fgm, fga):
    if fga == 0:
        return 0
    else:
        return float(fgm/fga)
def thr_fg_pct(tfgm, tfga):
    if tfga == 0:
        return 0
    else:
        return float(tfgm/tfga)
def ft_pct(ftm, fta):
    if fta == 0:
        return 0
    else:
        return float(ftm/fta)
def efg(fgm, tfgm, fga):
    if fga == 0:
        return 0
    else:
        return (fgm+(1.5*tfgm))/fga
def ts_pct(pts, fga, fta):
    if fga == 0:
        return 0
    else:
        return float(pts/(2*(fga +(0.44*fta))))
def tov_pct(tov, fga, fta):
    out = tov / (fga + 0.44*fta + tov)
    return out
#def reb_pct()

def height(inches):
    feet = (str)(math.floor(inches/12))
    inch = (str)(round(inches%12))

    out = "" + feet + "'" + inch + "''"
    return out

# Other #
def usage(fga, fta, tov, team_fga, team_fta, team_tov):
    out = (fga + 0.44*fta + tov) / (team_fga + 0.44*team_fta + team_tov)
    return out

#def offRtg():


def defRtg(pos, stl, blk, reb, team_reb, pf, oposs, per_d, post_d):
    stops = float(0.25*(stl+blk)/oposs)
    def_reb = 0.2*float(reb)/float(team_reb)
    foul_rate = float(0.1*pf/oposs)
    def_pct = 0

    if pos == "Guard":
        def_pct = float(0.25*per_d)
    elif pos == "Forward":
        def_pct = float(0.15*per_d) + float(0.15*post_d)
    else:
        def_pct = float(0.1*post_d)

    rtg = float(stops + def_reb - foul_rate - def_pct)
    return rtg



@player_views.route('/<int:player_id>')
def player_profile(player_id):
    players_data = load_data_from_csv('csv/final_sheet.csv')
    player = next((p for p in players_data if int(p['id']) == player_id), None)

    if player:
        player['height'] = height(player['height_in'])
        # Calculate statistics and add them to the player dictionary
        # Per game numbers
        player['ppg'] = round(ppg(int(player['pts']), int(player['games'])), 1)
        player['rpg'] = round(rpg(int(player['reb']), int(player['games'])), 1)
        player['apg'] = round(apg(int(player['ast']), int(player['games'])), 1)
        player['bpg'] = round(bpg(int(player['blk']), int(player['games'])), 1)
        player['spg'] = round(spg(int(player['stl']), int(player['games'])), 1)
        player['ppp'] = round(ppp(int(player['pts']), int(player['poss'])), 3)
        player['atr'] = round(atr(int(player['ast']), int(player['to'])), 2)
        # Efficiency metrics
        player['fg_pct'] = round(100*fg_pct(int(player['fgm']), int(player['fga'])), 1)
        player['thr_fg_pct'] = round(100*thr_fg_pct(int(player['threem']), int(player['threea'])), 1)
        player['ft_pct'] = round(100*ft_pct(int(player['ftm']), int(player['fta'])), 1)
        player['efg'] = round(100*efg(int(player['fgm']), int(player['threem']), int(player['fga'])), 1)
        player['ts_pct'] = round(100*ts_pct(int(player['pts']), int(player['fga']), int(player['fta'])), 1)
        # Ratings
        player['usage'] = round(100*usage(int(player['fga']), int(player['fta']), int(player['to']), int(player['team_fga']), int(player['team_fta']), int(player['team_tov'])), 1)
        #player['offRtg'] = offRtg()
        player['defRtg'] = round(100*defRtg(player['position'], int(player['stl']), int(player['blk']), int(player['reb']),
            player['team_reb'], int(player['fouls']), (int(player['pd_poss'] + player['intd_poss'])),
            int(player['pd_fg_pct']), int(player['intd_fg'])), 1)

        name = player['first_name'] + " " + player['last_name']
        ID = (str)(player['id'])
        team = player['team_name']

        return render_template('player_profile.html', player=player, name=name, ID=ID, team=team)
    else:
        return "Player not found"  # Handle the case where the player doesn't exist
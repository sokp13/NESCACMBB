import pandas as pd

# merge player, team, and totals
a = 
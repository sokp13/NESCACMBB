from flask import Flask
from loader import load_data_from_csv  # Import the data loading function

app = Flask(__name__)

players_data = load_data_from_csv('csv/final_sheet.csv')

# Import the player_views blueprint below
from player_views import player_views

app.register_blueprint(player_views, url_prefix='/players')

if __name__ == '__main__':
    app.run()